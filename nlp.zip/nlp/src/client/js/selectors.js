
function selector(){
  let message = document.getElementById('message');
    let agreement = document.getElementById('agreement');
      let irony = document.getElementById('irony');
        let subjectivty = document.getElementById('subjectivity');
          let confidence = document.getElementById('confidence');
            let scoretag = document.getElementById('scoretag');

}
          export{selector}
